# Handoff: Gibberish → Hebrew Transliteration Dialog

## Overview
A modal dialog that receives a pre-selected string of "gibberish" — Hebrew words written phonetically in English letters (e.g. `shalom`, `beseder`) — and displays a suggested Hebrew transliteration. The user can edit the suggestion before confirming or cancelling.

## About the Design Files
The file `Gibberish to Hebrew Dialog.html` is a **high-fidelity design reference** built in plain HTML/CSS/JS. It is not production code. Your task is to **recreate this UI in your existing codebase** using your established framework (React, Vue, SwiftUI, etc.) and component library. Adapt the structure, tokens, and logic — do not ship the HTML directly.

## Fidelity
**High-fidelity.** Pixel-perfect: final colors, typography, spacing, interactions, and transliteration logic are all specified. Recreate as closely as possible within your environment.

---

## Dialog Structure

### Layout
- Centered modal, `width: 520px`, `max-width: 100%`
- Three vertical sections: **Header**, **Body**, **Footer**
- `border-radius: 12px`, `border: 1px solid #border`, white background
- Entry animation: fade-in + translateY(10px→0) + scale(0.98→1), duration 250ms, easing `cubic-bezier(0.22, 1, 0.36, 1)`
- Box shadow: `0 8px 40px rgba(dark/12%), 0 2px 8px rgba(dark/6%)`

---

### Header
- `padding: 20px 24px 16px`, `border-bottom: 1px solid border-color`
- Horizontal flex row, `gap: 10px`, vertically centered
- **Icon badge**: 32×32px, rounded 8px, accent-light background (`#e8eeff` approx), accent-colored SVG icon inside (lines + Hebrew-aleph shape)
- **Title**: `"המרת כתיב גיבריש לעברית"` — 15px, weight 600, dark color, `letter-spacing: -0.01em`

---

### Body
- `padding: 20px 24px`, flex column, `gap: 16px`

#### Source Block (read-only)
- Background: very light cool gray (`oklch(0.97 0.004 260)` ≈ `#f4f5f8`)
- Border: `1px solid border-color`, `border-radius: 8px`, `padding: 12px 14px`
- Text: 14px, `color: oklch(0.45 0.01 260)` ≈ `#6b7080`, `line-height: 1.65`
- Content: the pre-selected gibberish string (multi-line, `white-space: pre-wrap`)
- **This text is passed in from outside the dialog (OOS)**

#### Divider
- Full-width horizontal rule — two `1px` lines with a centered icon (down-arrow SVG) between them
- Color: muted/border tone

#### Result Block (editable suggestion)
- Border: `1.5px solid accent` (`#3b5bdb` approx)
- Background: accent-light (`oklch(0.94 0.05 255)` ≈ `#e8eeff`)
- `border-radius: 8px`, `padding: 12px 14px`
- Contains an auto-resizing `<textarea>`:
  - Font: **Frank Ruhl Libre** (Google Fonts), fallback `Arial Hebrew, serif`
  - Font size: 18px, weight 400, `line-height: 1.8`
  - `direction: rtl`, `text-align: right`
  - No border, no outline, transparent background, no resize handle
  - `min-height: 48px`; grows to fit content
  - Editable by the user before confirming

---

### Footer
- `padding: 14px 24px`, `border-top: 1px solid border-color`
- Flex row, `direction: rtl` (buttons read right-to-left: **בצע** then **בטל**)
- `gap: 8px`

#### Button — בצע (Apply)
- Background: accent blue (`oklch(0.52 0.18 255)` ≈ `#3b5bdb`)
- Text: white, 14px, weight 500
- `padding: 8px 20px`, `border-radius: 7px`
- Hover: darken slightly (`oklch(0.46 0.18 255)`), stronger shadow
- Active: `scale(0.97)`
- On click: apply the Hebrew textarea value back to the calling context

#### Button — בטל (Cancel)
- Background: transparent, `border: 1px solid border-color`
- Text: muted color, 14px, weight 500
- `padding: 8px 20px`, `border-radius: 7px`
- Hover: light gray fill, text darkens
- On click: dismiss the dialog without applying

---

## Transliteration Engine

Implement the following logic to convert the input string to Hebrew:

### Step 1 — Map patterns (check digraphs before single letters)

| Input | Hebrew |
|-------|--------|
| `tsh` / `tzh` | צ |
| `sh` | ש |
| `ch` | ח |
| `kh` | כ |
| `tz` / `ts` | צ |
| `th` | ת |
| `ph` | פ |
| `gh` / `dj` | ג |
| `b` | ב |
| `v` | ו |
| `g` | ג |
| `d` | ד |
| `h` | ה |
| `z` | ז |
| `y` | י |
| `k` | כ |
| `l` | ל |
| `m` | מ |
| `n` | נ |
| `p` | פ |
| `f` | פ |
| `r` | ר |
| `s` | ס |
| `t` | ט |
| `q` | ק |
| `w` | ו |
| `x` | כס |
| `j` | ג׳ |
| `a` / `e` | א |
| `i` | י |
| `o` / `u` | ו |

### Step 2 — Final letter forms
After mapping each word, check the **last character** and replace with its final form:

| Regular | Final |
|---------|-------|
| מ | ם |
| נ | ן |
| פ | ף |
| כ | ך |
| צ | ץ |

### Step 3 — Preserve structure
- Process line by line (preserve `\n`)
- Only run the mapping on Latin letter sequences; pass through punctuation and spaces unchanged

---

## Design Tokens

| Token | Value | Approx Hex |
|-------|-------|------------|
| `--bg` | `oklch(0.97 0.005 260)` | `#f3f4f8` |
| `--surface` | white | `#ffffff` |
| `--border` | `oklch(0.88 0.008 260)` | `#d8dae3` |
| `--muted` | `oklch(0.60 0.010 260)` | `#8b8fa8` |
| `--text` | `oklch(0.18 0.012 260)` | `#1e2030` |
| `--accent` | `oklch(0.52 0.18 255)` | `#3b5bdb` |
| `--accent-lt` | `oklch(0.94 0.05 255)` | `#e8eeff` |
| `--radius` | `12px` | — |

---

## Typography

| Role | Font | Size | Weight |
|------|------|------|--------|
| UI / body | DM Sans (Google Fonts) | 14–15px | 400–600 |
| Hebrew output | Frank Ruhl Libre (Google Fonts) | 18px | 400 |

Google Fonts import:
```
https://fonts.googleapis.com/css2?family=DM+Sans:wght@300;400;500;600&family=Frank+Ruhl+Libre:wght@300;400;500;700&display=swap
```

---

## Props / API

The dialog should accept:
- `inputText: string` — the pre-selected gibberish string (multi-line supported)
- `onApply: (hebrewText: string) => void` — called when the user clicks בצע
- `onCancel: () => void` — called when the user clicks בטל

The transliteration runs client-side on mount, populating the editable suggestion. The user may edit before confirming.

---

## Accessibility
- `role="dialog"`, `aria-modal="true"`, `aria-labelledby` pointing to the title element
- Buttons have visible labels in Hebrew
- Textarea is focusable and keyboard-accessible
- Trap focus within the dialog while open (implement in your framework)
- `Escape` key should trigger cancel

---

## Files
- `Gibberish to Hebrew Dialog.html` — full hifi reference with embedded transliteration engine and all styles
